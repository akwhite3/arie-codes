/**
 * It is okay to use ArrayList class but you are not allowed to use any other
 * predefined class supplied by Java.
 */
import java.util.ArrayList;

public class CompressDecompress
{
	/**
	 * Get a string representing a Huffman tree where its root node is root
	 * @param root the root node of a Huffman tree
	 * @return a string representing a Huffman tree
	 */
	public static String getTreeString(final BinaryNodeInterface<Character> root)
	{
		// TO DO
		/**Use ArrayList to get the Children in order*/
		ArrayList<BinaryNodeInterface<Character>> level = new ArrayList<BinaryNodeInterface<Character>>();
		StringBuilder TreeString = new StringBuilder();
		int i = 0;
		if (root == null)
			return "";
		else 
		{
			SimpleQueue<BinaryNodeInterface<Character>> queue = new SimpleQueue<BinaryNodeInterface<Character>>();
			queue.enqueue(root);  
            while(queue.getFront() != null)  
			{  
				BinaryNodeInterface<Character> current = queue.dequeue(); 
				if (current.getData() == null)
					TreeString.append("I");
				else 
					TreeString.append("L" + current.getData());
				
				if(current.hasLeftChild())  
					queue.enqueue(current.getLeftChild());  
				if(current.hasRightChild())  
					queue.enqueue(current.getRightChild());  
			}
			return TreeString.toString();
		}
	}

	/**
	 * Compress the message using Huffman tree represented by treeString
	 * @param root the root node of a Huffman tree
	 * @param message the message to be compressed
	 * @return a string representing compressed message.
	 */
	public static String compress(final BinaryNodeInterface<Character> root, final String message)
	{
		// TO DO
		StringBuilder pathString = new StringBuilder();
		if (message == null || message == "")
			return "";
		else 
		{ 	
			int h = root.getHeight();
			int possiblePositions = (int) Math.pow(2,h) - 1;
			
			ArrayList<Integer> positions = new ArrayList<Integer>();
			for (int a = 1; a <= possiblePositions; a++)
				positions.add(a);
	
			int b = 0; // goes through the letters in the tree string
			int start = 0; // goes through the ArrayList
			int count = 0;
			String tree = getTreeString(root);
			ArrayList<Character> letters = new ArrayList<Character>();
			ArrayList<Integer> cannot = new ArrayList<Integer>();
			while ( b < tree.length() )
			{
				if (tree.charAt(b) == 'I')
				{
					positions.remove(start);
				}
				else if (tree.charAt(b) == 'L')
				{
					/**right here, we need to delete the entries that can't be added*/
					cannot.add(positions.get(start));
					b++;
					letters.add(tree.charAt(b));
					start++;
				}
				else
				{
					//I don't need an else
				}
				b++;
				//**eliminate the impossible elements*/
				int c = 0;
				while (c < cannot.size())
				{
					int num = cannot.get(c);
					int numA = num*2;
					int numB = num*2 + 1; 
					if (numA <= possiblePositions)
					{
						positions.remove((Integer) numA);
						cannot.add(numA);
					}
					if (numB <= possiblePositions)
					{
						positions.remove((Integer) numB);
						cannot.add(numB);
					}
					c++;
				}
			}
			int size = positions.size();
			/**trim the ArrayList to fit the size of the letters*/
			for (int d = letters.size(); d < size; d++)
				positions.remove(letters.size());
			
			/**Now that the ArrayList is right, we can go through the list and make a path string*/
			StringBuilder completeString = new StringBuilder();
			int e = 0;
			int pos = 0;
			while (e < message.length())
			{
				StringBuilder thisRow = new StringBuilder();
				char thisLetter = message.charAt(e);
				boolean found = false;
				int find = 0;
				while (!found)
				{
					if ((Character) thisLetter == letters.get(find))
						found = true;
					else 
						find++;
				}
				pos = positions.get(find);
				
				while (pos > 1)
				{
					thisRow.insert(0, Integer.toString(pos%2));
					pos = (int) pos/2;
				}
				completeString.append(thisRow.toString());
				e++;
			}
			return completeString.toString();
		}
	}
	
	/**
	 * Decompress the message using Huffman tree represented by treeString
	 * @param treeString the string represents the Huffman tree of the
	 * compressed message
	 * @param message the compressed message to be decompressed
	 * @return a string representing decompressed message
	 */
	public static String decompress(final String treeString, final String message)
	{
		if (message == "")
			return "";
		else 
		{
			StringBuilder path = new  StringBuilder();
			/** Make possible positions*/
			int possiblePositions = (int) 250;
			ArrayList<Integer> positions = new ArrayList<Integer>();
			for (int a = 1; a <= possiblePositions; a++)
				positions.add(a);
			
			/*the ArrayList is full, now we can eliminate the ones with that can't be possible*/
			int b = 0; // goes through the letters in the tree string
			int start = 0; // goes through the ArrayList
			int count = 0;
			ArrayList<Character> letters = new ArrayList<Character>();
			ArrayList<Integer> cannot = new ArrayList<Integer>();
			while ( b < treeString.length() )
			{
				if (treeString.charAt(b) == 'I')
				{
					positions.remove(start);
				}
				else if (treeString.charAt(b) == 'L')
				{
					/**right here, we need to delete the entries that can't be added*/
					cannot.add(positions.get(start));
					b++;
					letters.add(treeString.charAt(b));
					start++;
				}
				else
				{
					//I don't need an else
				}
				b++;
				//**eliminate the impossible elements*/
				int c = 0;
				while (c < cannot.size())
				{
					int num = cannot.get(c);
					int numA = num*2;
					int numB = num*2 + 1; 
					if (numA <= possiblePositions)
					{
						positions.remove((Integer) numA);
						cannot.add(numA);
					}
					if (numB <= possiblePositions)
					{
						positions.remove((Integer) numB);
						cannot.add(numB);
					}
					c++;
				}	
			}
			
			int size = positions.size();
			/**trim the ArrayList to fit the size of the letters*/
			for (int d = letters.size(); d < size; d++)
				positions.remove(letters.size());

			/**go through each number to see if it will add up to any of the positions of the characters*/
			int look = 0;
			int tryPosition = 1;
			while (look < message.length())
			{
				char thisMove = message.charAt(look);
				tryPosition = tryPosition*2 + Character.getNumericValue(thisMove);
				int foundIt = 0;
				boolean found = false;
				/*now look to see if it matches any of the positions*/
				for (int f = 0 ; f < positions.size() ; f++)
				{
					if (tryPosition == positions.get(f))
					{
						foundIt = f;
						found = true;
						break;
					}
				}
				
				if (found)
				{
					/*Do the operations to find the number*/
					tryPosition = 1;
					path.append((letters.get(foundIt)).toString());
				}
				look++;
			}
			
			return path.toString();
		}
	}
	
}
